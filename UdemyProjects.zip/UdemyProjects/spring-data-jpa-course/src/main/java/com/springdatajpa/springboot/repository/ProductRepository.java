package com.springdatajpa.springboot.repository;

import com.springdatajpa.springboot.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product,Long> {

    /**
     * Returns the found product entry by using its name as search
     * criteria .If no product entry is found , this method
     * returns null
     *
     */
    public Product findByName(String name);

    /**
     * Returns and Optional which contains the found product
     * entry by using its id as a search criteria.If no product entry
     * is found, this method returns an empty Optional.
     *
     */
    Optional<Product> findById(Long id);

    /**
     * Returns the found list of product entries whose name or description is given
     * as a method parameter.If no product entries is found , this method returns an
     * empty list.
     *
     */
    List<Product> findByNameOrDescription(String name, String description);

    /**
     * Returns the found list of product entries whose name and description is given
     * as a method parameter.If no product entries is found , this method returns an
     * empty list.
     *
     */
    List<Product> findByNameAndDescription(String name, String description);

    /**
     * Return the distinct product entry whose name is given as a method parameter
     * If no product entry is found , this method returns null
     *
     */
    Product findDistinctByName(String name);

    /**
     * Returns product whose price is greater than the given price as a parameter
     * @param price
     * @return
     */
    List<Product> findByPriceGreaterThan(BigDecimal price);

    /**
     * Returns product whose price is lesser than the given price as a parameter
     * @param price
     * @return
     */

    List<Product> findByPriceLessThan(BigDecimal price);

    /**
     * Returns the filtered the product records that match the given text
     * @param name
     * @return
     */
    List<Product> findByNameContaining(String name);

    /**
     * Returns products based on SQL LIKE condition
     * @param name
     * @return
     */
    List<Product> findByNameLike(String name);

    /**
     * Returns products BETWEEN the range of list of products price
     * @param startPrice
     * @param endPrice
     * @return
     */
    List<Product> findByPriceBetween(BigDecimal startPrice,BigDecimal endPrice);

    /**
     * Returns a Product whose dateCreated between start date and end date
     * @param startDate
     * @param endDate
     * @return
     */
    List<Product> findByDateCreatedBetween(LocalDateTime startDate,LocalDateTime endDate);

    /**
     * Returns list of products based on multiple values
     * @param names
     * @return
     */
    List<Product> findByNameIn(List<String> names);

    /**
     *
     * @return
     */
    List<Product> findFirst2ByOrderByNameAsc();

    /**
     *
     */
    List<Product> findTop2ByOrderByPriceDesc();
}
