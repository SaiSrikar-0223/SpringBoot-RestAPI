package com.springboot.firstapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFirstAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
