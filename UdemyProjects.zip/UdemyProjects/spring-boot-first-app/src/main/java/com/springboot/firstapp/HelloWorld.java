package com.springboot.firstapp;

public class HelloWorld {

    public String helloWorld(){
        return "Hello World";
    }
}
